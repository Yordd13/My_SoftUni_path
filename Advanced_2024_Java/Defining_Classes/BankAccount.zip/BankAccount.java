package Defining_Classes;

public class BankAccount {
    private int id;
    private double balance = 0;
    private final static double DEFAULT_INTEREST_RATE = 0.02d;

    private static int bankAccountCount = 1;
    private static double interestRate = DEFAULT_INTEREST_RATE;


    BankAccount(){

        this.id = bankAccountCount++;
    }
    public static void setInterestValue(double interestValue) {

        BankAccount.interestRate = interestValue;
    }

    double getInterestValue(int years) {

        return BankAccount.interestRate * years * this.balance;
    }

    void deposit(double amount){

        this.balance += amount;
    }

    public int getId() {
        return id;
    }
}

