package Defining_Classes;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        Map<Integer,BankAccount> accounts = new TreeMap<>();

        while (true){
            String[] line = scan.nextLine().split("\\s+");
            if(line[0].equals("End")){
                return;
            }

            switch (line[0]){
                case "Create":
                    BankAccount bankAccount = new BankAccount();
                    accounts.putIfAbsent(bankAccount.getId(),bankAccount);
                    System.out.printf("Account ID%d created%n",bankAccount.getId());
                    break;
                case "Deposit":
                    int id = Integer.parseInt(line[1]);
                    double amount = Double.parseDouble(line[2]);
                    if(!accounts.containsKey(id)){
                        System.out.println("Account does not exist");
                    }
                    else {
                        accounts.get(id).deposit(amount);
                        System.out.printf("Deposited %s to ID%d%n",new DecimalFormat("#.##").format(amount),id);
                    }
                    break;
                case "SetInterest":
                    double newInterest = Double.parseDouble(line[1]);
                    BankAccount.setInterestValue(newInterest);
                    break;
                case "GetInterest":
                    int id1 = Integer.parseInt(line[1]);
                    int years = Integer.parseInt(line[2]);
                    if(!accounts.containsKey(id1)){
                        System.out.println("Account does not exist");
                    }
                    else {
                        double interest = accounts.get(id1).getInterestValue(years);
                        System.out.printf("%.2f%n",interest);
                    }
                    break;
            }

        }
    }
}

