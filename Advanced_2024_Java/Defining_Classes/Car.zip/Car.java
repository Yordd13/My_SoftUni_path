package Defining_Classes.Exercises;

public class Car {
    private String model;
    private double fuelAmount;
    private double fuelPer1km;
    private int distanceTravelled = 0;

    Car(String model,double fuelAmount, double fuelPer1km){
        this.model = model;
        this.fuelAmount = fuelAmount;
        this.fuelPer1km = fuelPer1km;
    }

    public boolean canDrive(int kmDistance){
        boolean canDrive = true;
        if(fuelPer1km * kmDistance <= fuelAmount){
            fuelAmount -= fuelPer1km * kmDistance;
            distanceTravelled += kmDistance;
        }
        else canDrive = false;

        return canDrive;
    }

    @Override
    public String toString() {
        return String.format("%s %.2f %d", model, fuelAmount, distanceTravelled);
    }
}
