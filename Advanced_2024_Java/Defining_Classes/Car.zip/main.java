package Defining_Classes.Exercises;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        Map<String,Car> cars = new LinkedHashMap<>();

        for (int i = 0; i < n; i++) {
            String[] line = scan.nextLine().split("\\s+");
            String model = line[0];
            double fuelAmount = Double.parseDouble(line[1]);
            double fuelPer1km = Double.parseDouble(line[2]);

            Car car = new Car(model,fuelAmount,fuelPer1km);
            cars.putIfAbsent(model,car);
        }

        String input = scan.nextLine();
        while (!input.equals("End")){

            String[] line = input.split("\\s+");
            String model = line[1];
            int km = Integer.parseInt(line[2]);

            if(!cars.get(model).canDrive(km)){
                System.out.println("Insufficient fuel for the drive");
            }

            input = scan.nextLine();
        }

        for (Map.Entry<String,Car> entry : cars.entrySet()){
            System.out.println(entry.getValue().toString());
        }
    }
}
