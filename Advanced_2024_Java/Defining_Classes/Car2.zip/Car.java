package Defining_Classes;

public class Car {
    private String model;
    private int enginePower;
    private String cargoType;
    private Tire tire1;
    private Tire tire2;
    private Tire tire3;
    private Tire tire4;

    Car(String model, int enginePower, String cargoType, double pressure1,double pressure2,double pressure3,double pressure4){
        this.model = model;
        this.cargoType = cargoType;
        this.enginePower = enginePower;
        this.tire1 = new Tire(pressure1);
        this.tire2 = new Tire(pressure2);
        this.tire3 = new Tire(pressure3);
        this.tire4 = new Tire(pressure4);
    }

    public String getModel() {
        return model;
    }

    public String getCargoType() {
        return cargoType;
    }

    public boolean pressureUnder1(){
        return this.tire1.getPressure() < 1 || this.tire2.getPressure() < 1 || this.tire3.getPressure() < 1 || this.tire4.getPressure() < 1;
    }
    public boolean horsePowerBetterThan250(){
        return this.enginePower > 250;
    }
}
