package Defining_Classes;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        Map<String,Car> cars = new LinkedHashMap<>();

        for (int i = 0; i < n; i++) {
            String[] input = scan.nextLine().split("\\s+");

            Function<String,Double> func = Double::parseDouble;

            Car car = new Car(input[0],Integer.parseInt(input[2]),input[4], func.apply(input[5]), func.apply(input[7]), func.apply(input[9]),func.apply(input[11]));

            cars.putIfAbsent(input[0],car);
        }

        String condition = scan.nextLine();

        for (Map.Entry<String,Car> entry : cars.entrySet()) {
            if(entry.getValue().getCargoType().equals(condition) && condition.equals("fragile") && entry.getValue().pressureUnder1()){
                System.out.println(entry.getValue().getModel());
            }
            else if(entry.getValue().getCargoType().equals(condition) && condition.equals("flamable") && entry.getValue().horsePowerBetterThan250()){
                System.out.println(entry.getValue().getModel());
            }
        }
    }
}
