package Defining_Classes.Exercises;

import java.util.*;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        Map<String, List<Employee>> departments = new HashMap<>();

        for (int i = 0; i < n; i++) {
            String[] line = scan.nextLine().split("\\s+");
            String name = line[0];
            double salary = Double.parseDouble(line[1]);
            String position = line[2];
            String department = line[3];
            String email = "n/a";
            int age = -1;
            if(line.length == 5){
                if(Character.isDigit(line[4].charAt(0))){
                    age = Integer.parseInt(line[4]);
                }
                else {
                    email = line[4];
                }
            }
            else if(line.length == 6){
                email = line[4];
                age = Integer.parseInt(line[5]);
            }
                Employee employee = new Employee(name,salary,position,department,email, age);
                departments.putIfAbsent(employee.getDepartment(), new ArrayList<>());
                departments.get(employee.getDepartment()).add(employee);

        }

        getResult(departments, getHighestSalaryDepartment(departments));

    }
    public static String getHighestSalaryDepartment(Map<String,List<Employee>> departments){
        String bestDepartment = null;

        double bestSum = 0;
        for (Map.Entry<String,List<Employee>> entry : departments.entrySet()){
            double sum = 0;
            for (int i = 0; i < entry.getValue().size(); i++) {
                sum += entry.getValue().get(i).getSalary();
            }
            if(sum / entry.getValue().size() > bestSum){
                bestSum = sum / entry.getValue().size();
                bestDepartment = entry.getKey();
            }
        }

        return bestDepartment;
    }

    public static void getResult(Map<String,List<Employee>> departments, String bestOne){

        List<Employee> list = new ArrayList<>();

        for (Map.Entry<String,List<Employee>> entry : departments.entrySet()){
            for (int i = 0; i < entry.getValue().size(); i++) {
                if(entry.getValue().get(i).getDepartment().equals(bestOne)){
                    list.add(entry.getValue().get(i));
                }
                else break;
            }

        }

        System.out.printf("Highest Average Salary: %s%n",bestOne);

        while (!list.isEmpty()){
            double best = 0;
            int index = 0;
            for (int i = 0; i < list.size(); i++) {
                if(best < list.get(i).getSalary()){
                    best += list.get(i).getSalary();
                    index = i;
                }
            }
            System.out.println(list.get(index).toString());
            list.remove(index);
        }

    }
}