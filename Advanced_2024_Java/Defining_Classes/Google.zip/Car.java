package Defining_Classes;

public class Car {
    private String model;
    private int speed;
    Car(String model,int speed){
        this.model = model;
        this.speed = speed;
    }
    @Override
    public String toString() {
        if(!model.isEmpty()){
            return String.format("%s %d",model,speed);
        }
        else return "";
    }
}
