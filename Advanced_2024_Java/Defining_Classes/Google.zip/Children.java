package Defining_Classes;

public class Children {
    private String name;
    private String birthday;
    Children(String name, String birthday){
        this.name = name;
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        if(!name.isEmpty()){
            return String.format("%s %s",name,birthday);
        }
        else return "";
    }
}
