package Defining_Classes;

import java.util.ArrayList;
import java.util.List;

public class Google {
    private String name;
    private Company company;
    private List<Pokemon> pokemons = new ArrayList<>();
    private List<Children> children = new ArrayList<>();
    private List<Parents> parents = new ArrayList<>();
    private Car car;

    public void setName(String name) {
        this.name = name;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public void setPokemons(Pokemon pokemon) {
        this.pokemons.add(pokemon);
    }

    public void setChildren(Children children) {
        this.children.add(children);
    }

    public void setParents(Parents parent) {
        this.parents.add(parent);
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public void result(){
        System.out.println(this.name);
        System.out.println("Company:");
        if(company != null)System.out.println(company.toString());
        System.out.println("Car:");
        if(car != null)System.out.println(car.toString());
        System.out.println("Pokemon:");
        if(pokemons != null) {
            for (Pokemon pokemon : pokemons) {
                System.out.println(pokemon.toString());
            }
        }
        System.out.println("Parents:");
        if(parents != null) {
            for (Parents parent : parents) {
                System.out.println(parent.toString());
            }
        }
        System.out.println("Children:");
        if(children != null) {
            for (Children child : children) {
                System.out.println(child.toString());
            }
        }
    }

}
