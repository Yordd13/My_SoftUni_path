package Defining_Classes;

public class Parents {
    private String name;
    private String birthday;
    Parents(String name, String birthday){
        this.name = name;
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        if(!name.isEmpty()){
            return String.format("%s %s",name,birthday);
        }
        else return "";
    }
}
