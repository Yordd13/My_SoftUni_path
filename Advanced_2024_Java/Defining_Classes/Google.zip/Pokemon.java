package Defining_Classes;

public class Pokemon {
    private String pokemonName;
    private String pokemonType;

    Pokemon(String pokemonName, String pokemonType){
        this.pokemonName = pokemonName;
        this.pokemonType = pokemonType;
    }

    @Override
    public String toString() {
        if(!pokemonType.isEmpty()){
            return String.format("%s %s",pokemonName,pokemonType);
        }
        else return "";
    }
}
