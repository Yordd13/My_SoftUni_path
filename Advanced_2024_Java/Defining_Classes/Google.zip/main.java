package Defining_Classes;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        Map<String,Google> account = new LinkedHashMap<>();

        String line = scan.nextLine();
        while (!line.equals("End")){
            String[] input =line.split("\\s+");
            String namePerson = input[0];
            String command = input[1];
            String nameOperation = input[2];

            Google google = new Google();
            account.putIfAbsent(namePerson,google);
            account.get(namePerson).setName(namePerson);

            switch (command){
                case "company":
                    Company company = new Company(nameOperation,input[3],Double.parseDouble(input[4]));
                    account.get(namePerson).setCompany(company);
                    break;
                case "pokemon":
                    Pokemon pokemon = new Pokemon(nameOperation,input[3]);
                    account.get(namePerson).setPokemons(pokemon);
                    break;
                case "parents":
                    Parents parents = new Parents(nameOperation,input[3]);
                    account.get(namePerson).setParents(parents);
                    break;
                case "children":
                    Children children = new Children(nameOperation,input[3]);
                    account.get(namePerson).setChildren(children);
                    break;
                case "car":
                    Car car = new Car(nameOperation,Integer.parseInt(input[3]));
                    account.get(namePerson).setCar(car);
                    break;
            }

            line = scan.nextLine();
        }

        String name = scan.nextLine();

        account.get(name).result();
    }
}
