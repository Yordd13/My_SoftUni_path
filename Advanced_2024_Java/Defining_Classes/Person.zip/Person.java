package Defining_Classes.Exercises;

public class Person {
    private String name;
    private int age;

    Person(String name, int age){
        this.age = age;
        this.name = name;
    }
    public int getAge() {
        return this.age;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return String.format("%s - %d%n",this.name,this.age);
    }
}
