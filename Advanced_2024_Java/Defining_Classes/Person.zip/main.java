package Defining_Classes.Exercises;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        Map<String,Person> people = new TreeMap<>();

        for (int i = 0; i < n; i++) {
            String[] line = scan.nextLine().split("\\s+");
            Person person = new Person(line[0],Integer.parseInt(line[1]));

            if(Integer.parseInt(line[1] ) > 30){
                people.putIfAbsent(line[0],person);
            }

        }

        for (Map.Entry<String,Person> entry : people.entrySet()){
            System.out.print(entry.getValue().toString());
        }
    }
}
