package Defining_Classes;

import java.util.ArrayList;
import java.util.List;

public class Trainer {
    private String name;
    private int badgesAmount = 0;
    private List<Pokemon>  pokemons = new ArrayList<>();

    public void setPokemons(Pokemon pokemon) {
        this.pokemons.add(pokemon);
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBadgesAmount() {
        return badgesAmount;
    }

    public String getName() {
        return name;
    }

    public boolean checkForElement(String element){
        boolean output = false;
        for (Pokemon pokemon : pokemons){
            if(pokemon.getElement().equals(element)){
                output = true;
                break;
            }
        }
        return output;
    }

    public void increaseBadges(){
        this.badgesAmount += 1;
    }

    public void removeHealth(){

        for (Pokemon pokemon : pokemons){
            pokemon.decreaseHealth();
            if(pokemon.checkForDeath()){
                pokemons.remove(pokemon);
                return;
            }
        }

    }

    @Override
    public String toString() {
        return String.format("%s %d %d",this.name,this.badgesAmount,this.pokemons.size());
    }
}
