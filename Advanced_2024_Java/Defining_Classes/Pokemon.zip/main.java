package Defining_Classes;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String line = scan.nextLine();

        Map<String,Trainer> map = new LinkedHashMap<>();

        while (!line.equals("Tournament")){
            String[] input = line.split("\\s+");

            Trainer trainer = new Trainer();
            trainer.setName(input[0]);

            Pokemon pokemon = new Pokemon(input[1],input[2],Integer.parseInt(input[3]));
            trainer.setPokemons(pokemon);

            if(map.containsKey(input[0])){
                map.get(input[0]).setPokemons(pokemon);
            }
            else map.putIfAbsent(input[0],trainer);

            line = scan.nextLine();
        }

        line = scan.nextLine();

        while (!line.equals("End")){

            for (Map.Entry<String,Trainer> entry : map.entrySet()){
                if(entry.getValue().checkForElement(line)){
                    entry.getValue().increaseBadges();
                }
                else {
                    entry.getValue().removeHealth();
                }
            }

            line = scan.nextLine();
        }

        result(map,getTheBest(map));
    }
    public static void result(Map<String,Trainer> trainers, Trainer trainer){
        while (!trainers.isEmpty()){
            System.out.println(getTheBest(trainers));
            trainers.remove(getTheBest(trainers).getName());
        }
    }
    public static Trainer getTheBest(Map<String,Trainer> trainers){
        Trainer trainer = null;

        int countBest = -1;
        for (Map.Entry<String,Trainer> entry : trainers.entrySet()){
            if(countBest == entry.getValue().getBadgesAmount()){
                continue;
            }
            else if(countBest < entry.getValue().getBadgesAmount()) {
                countBest = entry.getValue().getBadgesAmount();
                trainer = entry.getValue();
            }
        }
        return trainer;
    }
}
