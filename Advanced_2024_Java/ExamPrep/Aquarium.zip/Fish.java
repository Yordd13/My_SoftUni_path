public class Fish {
    private String name;
    private String color;
    private int fins;

    public Fish(String name, String color, int fins){
        this.color = color;
        this.fins = fins;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public int getFins() {
        return fins;
    }

    @Override
    public String toString() {
        return "Fish: " + name + "\n" +
                "Color: " + color + "\n" +
                "Number of fins: " + fins;
    }
}

