package parrots;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Cage {
    private String name;
    private int capacity;
    private List<Parrot> data;

    public Cage(String name, int capacity){
        this.capacity = capacity;
        this.name = name;
        this.data = new ArrayList<>();
    }

    public String getName() {
        return this.name;
    }

    public int getCapacity() {
        return this.capacity;
    }
    public void add(Parrot parrot) {
        if(this.data.size() < this.capacity){
            this.data.add(parrot);
        }

    }
    public boolean remove(String name){
        for (int i = 0; i < this.data.size(); i++) {
            if (this.data.get(i).getName().equals(name)) {
                this.data.remove(i);
                return true;
            }
        }
        return false;
    }

    public Parrot sellParrot(String name){
        for (Parrot bird : this.data) {
            if(bird.getName().equals(name)){
                bird.setAvailable(false);
                return bird;
            }
        }
        return null;
    }

    public List<Parrot> sellParrotBySpecies(String species){
        List<Parrot> data2 = new ArrayList<>();
        for (Parrot bird : data){
            if(bird.getSpecies().equals(species)){
                data2.add(bird);
                bird.setAvailable(false);
            }
        }
        return data2;
    }

    public int count(){
        return data.size();
    }
    public String report(){
        String res = "Parrots available at " + this.name + ":\n";
        for(Parrot bird : data){
            if(bird.isAvailable()){
                res += bird.toString() + "\n";
            }
        }
        return res;
    }
}
