import java.util.ArrayList;
import java.util.List;

public class Box <T> {
    private final List<T> value;

    public Box(){
        this.value = new ArrayList<T>();
    }
    public void addElement(T item){
        value.add(item);
    }

    public String toString() {
        StringBuilder output = new StringBuilder();
        for (T value : this.value) {
            output.append(String.format("%s: %s",value.getClass().getName(),value.toString())).append(System.lineSeparator());
        }
        return output.toString().trim();
    }
    public void swapElements(int index1, int index2){
        T current = this.value.get(index1);
        this.value.set(index1,this.value.get(index2));
        this.value.set(index2,current);

    }
}

