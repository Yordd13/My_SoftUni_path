
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());
        Box<String> box = new Box<>();
        for (int i = 0; i < n; i++) {
            box.addElement(scan.nextLine());
        }

        String[] indexes = scan.nextLine().split(" ");
        int index1 = Integer.parseInt(indexes[0]);
        int index2 = Integer.parseInt(indexes[1]);

        box.swapElements(index1,index2);

        System.out.println(box.toString());
    }
}
