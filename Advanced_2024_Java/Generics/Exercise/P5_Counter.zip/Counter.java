import java.util.ArrayList;
import java.util.List;

public class Counter<T extends Comparable<T>> {
    private final List<T> lines;
    public Counter(){
        this.lines = new ArrayList<>();
    }
    public void addElement(T item){
        this.lines.add(item);
    }


    public void compare(String comparable){
        int counter = 0;

        for (int i = 0; i < lines.size(); i++) {
            if(comparable.compareTo(lines.get(i).toString()) < 0){
                counter++;
            }
        }
        System.out.println(counter);
    }
}
