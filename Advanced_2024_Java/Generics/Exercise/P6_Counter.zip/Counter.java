import java.util.ArrayList;
import java.util.List;

public class Counter<T extends Comparable<T>> {
    private final List<T> lines;
    public Counter(){
        this.lines = new ArrayList<>();
    }
    public void addElement(T item){
        this.lines.add(item);
    }


    public void compare(Double comparable){
        int counter = 0;

        for (T line : lines) {
            if (comparable - Double.parseDouble(line.toString()) < 0) {
                counter++;
            }
        }
        System.out.println(counter);
    }
}
