import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] line = scan.nextLine().split("\\s+");

        CustomList<String> list = new CustomList<>();

        while (!line[0].equals("END")){

            String command = line[0];

            switch (command){
                case "Add":
                    String element = line[1];
                    list.add(element);
                    break;
                case "Remove":
                    int index = Integer.parseInt(line[1]);
                    list.remove(index);
                    break;
                case "Contains":
                    String el = line[1];
                    System.out.println(list.contains(el));
                    break;
                case "Swap":
                    int index1 = Integer.parseInt(line[1]);
                    int index2 = Integer.parseInt(line[2]);
                    list.swap(index1,index2);
                    break;
                case "Greater":
                    String el1 = line[1];
                    System.out.println(list.counterGreaterThan(el1));
                    break;
                case "Max":
                    System.out.println(list.getMax());
                    break;
                case "Min":
                    System.out.println(list.getMin());
                    break;
                case "Print":
                    list.print();
                    break;
            }

            line = scan.nextLine().split("\\s+");
        }
    }
}
