import java.util.ArrayList;
import java.util.List;

public class CustomList<T extends Comparable<T>> {
    private List<T> items;
    public CustomList(){
        items = new ArrayList<>();
    }
    public void add(T element){
        this.items.add(element);
    }
    public T remove(int index){
        return this.items.remove(index);
    }
    public boolean contains(T element){
        return this.items.contains(element);
    }
    public void swap(int index1,int index2){
        T el1 = this.items.get(index1);
        T el2 = this.items.get(index2);
        this.items.set(index1,el2);
        this.items.set(index2,el1);
    }
    public int counterGreaterThan(T element){
        int counter = 0;

        for (T item : this.items) {
            if (item.compareTo(element) > 0) {
                counter++;
            }
        }
        return counter;
    }
    public T getMax(){
        if(this.items.isEmpty()){
            throw new IllegalArgumentException();
        }

        return this.items.stream().max(Comparable::compareTo).get();
    }
    public T getMin(){
        if(this.items.isEmpty()){
            throw new IllegalArgumentException();
        }

        return this.items.stream().min(Comparable::compareTo).get();
    }
    public void print(){
        for (T item : this.items) {
            System.out.println(item);
        }
    }
    public List<T> toSort(){
        return this.items;
    }
}
