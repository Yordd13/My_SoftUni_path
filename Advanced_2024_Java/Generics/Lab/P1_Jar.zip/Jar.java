package Generics.Lab;

import java.util.ArrayDeque;

public class Jar<E> {
    public ArrayDeque<E> deque = new ArrayDeque<>();

    public void add(E el){
        this.deque.push(el);
    }
    public E remove(){
        return this.deque.pop();
    }
}
