package sharkHaunt;

import java.util.ArrayList;
import java.util.List;

public class Basin {
    private List<Shark> sharks;
    private String name;
    private int capacity;

    public Basin(String name, int capacity){
        this.name = name;
        this.capacity = capacity;
        this.sharks = new ArrayList<>();
    }

    public void addShark(Shark shark){
        if(capacity > sharks.size()){
            sharks.add(shark);
        }
        else {
            System.out.println("This basin is at full capacity!");
        }
    }

    public boolean removeShark(String kind){
        for (Shark shark : sharks) {
            if(shark.getKind().equals(kind)){
                sharks.remove(shark);
                return true;
            }
        }
        return false;
    }

    public Shark getLargestShark(){
        Shark shark = null;
        int longest = 0;

        for (Shark animal : sharks) {
            if(animal.getLength() > longest){
                longest = animal.getLength();
                shark = animal;
            }
        }

        return shark;
    }

    public Shark getShark(String kind){
        Shark shark = null;
        for (Shark animal : sharks) {
            if(animal.getKind().equals(kind)){
                shark = animal;
                break;
            }
        }
        return shark;
    }

    public int getCount(){
        return sharks.size();
    }

    public int getAverageLength(){
        int sum = 0;
        for (Shark shark : sharks) {
            sum += shark.getLength();
        }
        if(sharks.isEmpty()){
            return 0;
        }
        return sum / sharks.size();
    }

    public String report(){
        String res = "Sharks in " + name + ":\n";

        for (int i = 0; i < sharks.size(); i++) {
            if(i == sharks.size() - 1){
                res += sharks.get(i).toString();
            }
            else res += sharks.get(i).toString() + "\n";
        }
        return res;
    }
}
