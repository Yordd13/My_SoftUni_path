public class Person {
    private String name;
    private int age;

    public Person(String name, int age){
        this.age = age;
        this.name = name;
    }

    public boolean greaterThan30(int age){
        return this.age > 30;
    }

    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }
}
