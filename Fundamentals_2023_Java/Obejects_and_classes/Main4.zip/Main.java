import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Student> students = new ArrayList<>();

        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            String[] input = scan.nextLine().split(" ");
            String firstName = input[0];
            String lastName = input[1];
            double garde = Double.parseDouble(input[2]);

            Student student = new Student(firstName,lastName,garde);

            students.add(student);
        }

        for (int i = 0; i < students.size(); i++) {
            String firstName = Student.BestGarde(students).getFirstName();
            String lastName = Student.BestGarde(students).getLastName();
            double age = Student.BestGarde(students).getGrade();
            students.remove(Student.BestGarde(students));
            i--;

            System.out.printf("%s %s: %.2f%n",firstName,lastName,age);
        }
    }
}
