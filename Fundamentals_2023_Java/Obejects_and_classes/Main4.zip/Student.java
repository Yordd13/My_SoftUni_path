import java.util.List;

public class Student {

    private String firstName;
    private String lastName;
    private double grade;

    public Student(String firstName, String lastName, double grade){
        this.firstName = firstName;
        this.lastName = lastName;
        this.grade = grade;
    }
    public String getLastName(){
        return this.lastName;
    }
    public String getFirstName(){
        return this.firstName;
    }
    public double getGrade(){
        return this.grade;
    }

    public static Student BestGarde(List<Student> students){
        Student bestOne = null;
        double max = Double.MIN_VALUE;

        for (Student student : students) {
            if(student.getGrade() > max){
                bestOne = student;
                max = student.getGrade();
            }
        }
        return bestOne;
    }
}
