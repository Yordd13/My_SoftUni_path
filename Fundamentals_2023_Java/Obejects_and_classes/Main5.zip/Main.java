import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Vehicle> vehicles = new ArrayList<>();

        while (true){
            String line = scan.nextLine();
            if(line.equals("End")){
                break;
            }
            String[] data = line.split(" ");

            Vehicle vehicle = new Vehicle(data[0],data[1],data[2],Integer.parseInt(data[3]));

            vehicles.add(vehicle);
        }

        while (true){
            String line = scan.nextLine();
            if(line.equals("Close the Catalogue")){
                break;
            }

            System.out.println("Type: " + Vehicle.vehicleFinder(vehicles,line).getTypeOfVehicle().substring(0,1).toUpperCase() + Vehicle.vehicleFinder(vehicles,line).getTypeOfVehicle().substring(1));
            System.out.println("Model: " + Vehicle.vehicleFinder(vehicles,line).getModel());
            System.out.println("Color: " + Vehicle.vehicleFinder(vehicles,line).getColor());
            System.out.println("Horsepower: " + Vehicle.vehicleFinder(vehicles,line).getHorsePower());
        }

        int sumHorsePowerCars = 0;
        int counterCars = 0;
        int sumHorsePowerTrucks = 0;
        int counterTrucks = 0;
        for (Vehicle vehicle : vehicles) {
            if(vehicle.getTypeOfVehicle().equals("car")){
                sumHorsePowerCars += vehicle.getHorsePower();
                counterCars++;
            }
            else {
                sumHorsePowerTrucks += vehicle.getHorsePower();
                counterTrucks++;
            }
        }
        if(counterCars == 0) counterCars = 1;
        if(counterTrucks == 0) counterTrucks = 1;

        System.out.printf("Cars have average horsepower of: %.2f.%n", sumHorsePowerCars * 1.0/ counterCars);
        System.out.printf("Trucks have average horsepower of: %.2f.", sumHorsePowerTrucks * 1.0/ counterTrucks);
    }
}
