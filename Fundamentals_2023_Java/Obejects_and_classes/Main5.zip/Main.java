import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Student> students = new ArrayList<>();

        while (true){
            String line = scan.nextLine();
            if(line.equals("end")){
                break;
            }
            String[] input = line.split(" ");

            String firstName = input[0];
            String lastName = input[1];
            int age = Integer.parseInt(input[2]);
            String homeTown = input[3];

            Student student = new Student(firstName,lastName,age,homeTown);

            students.add(student);
        }
        String filter = scan.nextLine();

        for (Student position : students){
            if(position.getHomeTown().equals(filter)){
                System.out.printf("%s %s is %d years old%n",position.getFirstName(),position.getLastName(),position.getAge(),position.getHomeTown());
            }
        }
    }
}
