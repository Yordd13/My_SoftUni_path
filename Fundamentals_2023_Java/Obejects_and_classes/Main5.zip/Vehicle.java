import java.util.List;

public class Vehicle {

    private String typeOfVehicle;
    private String model;
    private String color;
    private int horsePower;

    public Vehicle(String typeOfVehicle, String model, String color, int horsePower){
        this.horsePower = horsePower;
        this.color = color;
        this.typeOfVehicle = typeOfVehicle;
        this.model = model;
    }

    public String getTypeOfVehicle(){
        return this.typeOfVehicle;
    }
    public String getModel(){
        return this.model;
    }
    public String getColor(){
        return this.color;
    }
    public int getHorsePower(){
        return this.horsePower;
    }

    public static Vehicle vehicleFinder(List<Vehicle> vehicles, String model){
        Vehicle findVehicle = null;

        for (Vehicle vehicle : vehicles) {
            String model2 = vehicle.getModel();
            if(model2.equals(model)){
                findVehicle = vehicle;
            }
        }

        return findVehicle;
    }
}