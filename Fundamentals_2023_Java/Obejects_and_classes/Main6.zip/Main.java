import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Person> people = new ArrayList<>();

        while (true){
            String line = scan.nextLine();

            if(line.equals("End")){
                break;
            }

            String[] data = line.split(" ");

            Person person = new Person(data[0],data[1],Integer.parseInt(data[2]));
            people.add(person);
        }

        for (int i = 0; i < people.size();i++) {
            Person youngest = Person.getYoungest(people);
            System.out.printf("%s with ID: %s is %d years old.%n", youngest.getName(),youngest.getId(),youngest.getAge());
            people.remove(youngest);
            i--;
        }
    }
}
