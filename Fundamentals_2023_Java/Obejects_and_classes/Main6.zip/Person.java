import java.util.List;

public class Person {
    private String name;
    private String id;
    private int age;

    public Person(String name, String id, int age){
        this.name = name;
        this.id = id;
        this.age = age;
    }

    public String getName(){
        return this.name;
    }
    public String getId(){
        return this.id;
    }
    public int getAge(){
        return this.age;
    }

    public static Person getYoungest(List<Person> people){
        Person youngest = null;

        for (Person person: people) {
            if(youngest == null){
                youngest = person;
            }
            if(person.getAge() < youngest.age){
                youngest = person;
            }
        }
        return youngest;
    }
}