import java.util.List;

public class Student {
    private String firstName;
    private String lastName;
    private int age;
    private String homeTown;

    public Student(String firstName, String lastName, int age, String homeTown){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.homeTown = homeTown;
    }

    public String getFirstName(){
        return this.firstName;
    }
    public String getLastName(){
        return this.lastName;
    }
    public int getAge(){
        return this.age;
    }
    public String getHomeTown(){
        return this.homeTown;
    }

    public static boolean isStudentExisting(List<Student> students, String firstName, String lastName){
        for (Student student : students){
            if(student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)){
                return true;
            }
        }
        return false;
    }
    public static Student getStudent(List<Student> students,String firstName, String lastName, int age, String homeTown){
        Student existingStudent = null;

        for (Student student : students){
            if(student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)){
                existingStudent = student;
                existingStudent.age = age;
                existingStudent.homeTown = homeTown;
            }
        }
        return existingStudent;
    }
}
