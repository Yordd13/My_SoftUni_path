import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String name =scan.nextLine();
        System.out.println(name + ":");

        for (suitsDecks suit : suitsDecks.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",suit.getValue(),suit.name());
        }
    }
}
