import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String name = scan.nextLine();

        System.out.println(name + ":");
        for (RanksOfDeck rank : RanksOfDeck.values()){
            System.out.printf("Ordinal value: %d; Name value: %s\n",rank.getValue(),rank.name());
        }
    }
}
