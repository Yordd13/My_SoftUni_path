import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String[] input =scan.nextLine().split(" ");
        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < input.length; j++) {
                TrafficLight light = TrafficLight.valueOf(input[j]);
                if(light.equals(TrafficLight.YELLOW)){
                    light = TrafficLight.RED;
                }
                else if(TrafficLight.RED.equals(light)){
                    light = TrafficLight.GREEN;
                }
                else {
                    light = TrafficLight.YELLOW;
                }
                input[j] = light.name();
                System.out.print(light.name() + " ");
            }
            System.out.println();
        }
    }
}
