public enum TrafficLight {
    RED(1),GREEN(2),YELLOW(3);
    private int value;
    TrafficLight(int value){
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
