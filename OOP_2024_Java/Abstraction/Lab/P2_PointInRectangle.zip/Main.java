import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] rectanglePosition = scan.nextLine().split(" ");

        Point posBotLeft = new Point(Integer.parseInt(rectanglePosition[0]),Integer.parseInt(rectanglePosition[1]));
        Rectangle rectangle = new Rectangle();
        rectangle.setBotLeft(posBotLeft);

        Point posTopRight = new Point(Integer.parseInt(rectanglePosition[2]),Integer.parseInt(rectanglePosition[3]));
        rectangle.setTopRight(posTopRight);

        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            String[] line = scan.nextLine().split(" ");
            int x = Integer.parseInt(line[0]);
            int y = Integer.parseInt(line[1]);
            Point currPoint = new Point(x,y);

            System.out.println(rectangle.contains(currPoint));
        }
    }
}
