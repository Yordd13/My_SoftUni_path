public class Rectangle {
    private Point botLeft;
    private Point topRight;

    public void setBotLeft(Point botLeft) {
        this.botLeft = botLeft;
    }

    public void setTopRight(Point topRight) {
        this.topRight = topRight;
    }

    public boolean contains(Point point){
        int botLeftX = this.botLeft.getX();
        int botLeftY = this.botLeft.getY();
        int topRightX = this.topRight.getX();
        int topRightY = this.topRight.getY();

        return botLeftX <= point.getX() && topRightX >= point.getX()
                && botLeftY <= point.getY() && topRightY >= point.getY();
    }
}
