import java.util.HashMap;
import java.util.Map;

public class StudentSystem {
    private Map<String, Student> studentMap;

    public StudentSystem()
    {
        this.studentMap = new HashMap<>();
    }

    public void addStudent(Student student){
            if(!studentMap.containsKey(student.getName())){
                studentMap.put(student.getName(),student);
            }
    }
    public void showStudent(String name){
        if (studentMap.containsKey(name))
        {
            Student student = studentMap.get(name);
            String view = String.format("%s is %s years old.",student.getName(),student.getAge());

            if (student.getGrade() >= 5.00)
            {
                view += " Excellent student.";
            }
            else if (student.getGrade() < 5.00 && student.getGrade() >= 3.50)
            {
                view += " Average student.";
            }
            else
            {
                view += " Very nice person.";
            }

            System.out.println(view);
        }
    }
}
