public class PriceCalculator {
    public static double calculatePrice(double pricePerDay, int numberOfDays, Season season, Discount discount){
        pricePerDay *= season.getValue();
        double discountPercent = discount.getValue() / 100.0;

        double priceBeforeDiscount = numberOfDays * pricePerDay;
        double discountedAmount = priceBeforeDiscount * discountPercent;

        return priceBeforeDiscount - discountedAmount;
    }
}
