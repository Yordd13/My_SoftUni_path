import java.security.InvalidParameterException;

public class Chicken {
    private String name;
    private int age;

    public Chicken(String name, int age){
        this.setAge(age);
        this.setName(name);
    }

    private void setAge(int age) {
        if(age >= 0 && age <= 15){
            this.age = age;
        }
        else throw new InvalidParameterException("Age should be between 0 and 15.");
    }

    private void setName(String name) {
        if(name.isEmpty() || name.equals(" ")){
            throw new InvalidParameterException("Name cannot be empty.");
        }
        else this.name = name;
    }

    public double productPerDay(){
        return calculateProductPerDay();
    }

    @Override
    public String toString() {
        return String.format("Chicken %s (age %d) can produce %.2f eggs per day.",name,age,productPerDay());
    }
    private double calculateProductPerDay(){
        if(this.age < 6){
            return 2.0;
        }
        else if(this.age < 12){
            return 1.0;
        }
        else return 0.75;
    }
}
