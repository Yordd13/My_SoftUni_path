public enum BakingTechnique {
    Crispy,
    Chewy,
    Homemade,
}
