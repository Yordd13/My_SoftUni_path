public enum FlourType {
    White,
    Wholegrain
}
