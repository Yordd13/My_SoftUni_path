public enum ToppingType {
    Meat,
    Veggies,
    Cheese,
    Sauce,
}
