import java.lang.reflect.Method;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String line;

        List<Citizen> citizens = new ArrayList<>();
        List<Pet> pets = new ArrayList<>();

        while (!(line = scan.nextLine()).equals("End")){

            String[] commands = line.split("\\s+");

            switch (commands[0]){
                case "Citizen":
                    citizens.add(new Citizen(commands[1],Integer.parseInt(commands[2]),commands[3],commands[4]));
                    break;
                case "Pet":
                    pets.add(new Pet(commands[1],commands[2]));
                    break;
            }


        }
        String year = scan.nextLine();

        for (Citizen citizen : citizens) {
            String[] date = citizen.getBirthDate().split("/");
            if(date[2].equals(year)){
                System.out.println(citizen.getBirthDate());
            }
        }
        for (Pet pet : pets) {
            String[] date = pet.getBirthDate().split("/");
            if(date[2].equals(year)){
                System.out.println(pet.getBirthDate());
            }
        }
    }
}
