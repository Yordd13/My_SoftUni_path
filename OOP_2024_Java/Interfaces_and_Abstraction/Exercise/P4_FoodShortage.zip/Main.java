import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        Map<String,Buyer> buyers = new LinkedHashMap<>();

        for (int i = 0; i < n; i++) {
            String[] line = scan.nextLine().split("\\s+");
            String name = line[0];
            int age = Integer.parseInt(line[1]);

            if(line.length == 4){
                String id = line[2];
                String birthDate = line[3];
                buyers.put(name,new Citizen(name,age,id,birthDate));
            }
            else {
                String group = line[2];
                buyers.put(name,new Rebel(name,age,group));
            }
        }

        String line;
        while (!(line = scan.nextLine()).equals("End")){

            for(Map.Entry<String,Buyer> entry : buyers.entrySet()){
                if(entry.getKey().equals(line)){
                    entry.getValue().buyFood();
                    break;
                }
            }
        }

        System.out.println(boughtFoodSum(buyers));

    }
    public static int boughtFoodSum(Map<String,Buyer> map){
        int res = 0;
        for(Map.Entry<String,Buyer> entry : map.entrySet()){
            res += entry.getValue().getFood();
        }
        return res;
    }
}
