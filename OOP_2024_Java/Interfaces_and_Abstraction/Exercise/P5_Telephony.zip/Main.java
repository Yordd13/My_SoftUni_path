import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] numbers = scan.nextLine().split(" ");
        List<String> nums = new ArrayList<>();

        for (int i = 0; i < numbers.length; i++) {
            nums.add(numbers[i]);
        }

        String[] sites = scan.nextLine().split(" ");
        List<String> urls = new ArrayList<>();

        for (int i = 0; i < sites.length; i++) {
            urls.add(sites[i]);
        }

        Smartphone smartphone = new Smartphone(nums,urls);
        System.out.println(smartphone.call());
        System.out.println(smartphone.browse());
    }
}
