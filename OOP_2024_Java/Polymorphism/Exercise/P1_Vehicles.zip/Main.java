import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] carTokens = scan.nextLine().split("\\s+");
        String[] truckTokens = scan.nextLine().split("\\s+");

        Car car = new Car(Double.parseDouble(carTokens[1]),Double.parseDouble(carTokens[2]));
        Truck truck = new Truck((Double.parseDouble(truckTokens[1])),Double.parseDouble(truckTokens[2]));
        
        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            String[] tokens = scan.nextLine().split("\\s+");

            switch (tokens[0]){
                case "Drive":
                    switch (tokens[1]){
                        case "Car":
                            System.out.println(car.drive(Double.parseDouble(tokens[2])));
                            break;
                        case "Truck":
                            System.out.println(truck.drive(Double.parseDouble(tokens[2])));
                            break;
                    }
                    break;
                case "Refuel":
                    switch (tokens[1]){
                        case "Car":
                            car.refuel(Double.parseDouble(tokens[2]));
                            break;
                        case "Truck":
                            truck.refuel(Double.parseDouble(tokens[2]));
                            break;
                    }
                    break;
            }
        }

        System.out.printf("Car: %.2f%n",car.getFuelQuantity());
        System.out.printf("Truck: %.2f",truck.getFuelQuantity());
    }
}
