import java.text.DecimalFormat;

public abstract class VehicleImpl implements Vehicle{
    private double fuelQuantity;
    private double fuelConsumption;

    public VehicleImpl(double fuelQuantity, double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    @Override
    public String drive(double distance) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        if(getFuelQuantity() >= getFuelConsumption() * distance){
            this.fuelQuantity -= fuelConsumption * distance;
            return String.format("%s travelled %s km",this.getClass().getSimpleName(),decimalFormat.format(distance));
        }
        return this.getClass().getSimpleName() + " needs refueling";
    }

    @Override
    public void refuel(double litters) {
        this.fuelQuantity += litters;
    }
}
