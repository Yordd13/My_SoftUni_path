public class Bus extends VehicleImpl{
    private boolean isEmpty;
    private boolean isAcON;
    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
        isEmpty = true;
        isAcON = false;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean empty) {
        isEmpty = empty;
    }

    public boolean isAcON() {
        return isAcON;
    }

    public void setAcON(boolean acON) {
        isAcON = acON;
    }

    @Override
    public String drive(double distance) {

        if(isAcON){
            super.setFuelConsumption(super.getFuelConsumption() - 1.4);
            isAcON = false;
        }

        if(isEmpty){
            super.setFuelConsumption(super.getFuelConsumption() + 1.4);
            this.isAcON = true;
        }
        return super.drive(distance);
    }
}
