import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] carTokens = scan.nextLine().split("\\s+");
        String[] truckTokens = scan.nextLine().split("\\s+");
        String[] busTokens = scan.nextLine().split("\\s+");


        Car car = new Car(Double.parseDouble(carTokens[1]),Double.parseDouble(carTokens[2]),Double.parseDouble(carTokens[3]));
        Truck truck = new Truck((Double.parseDouble(truckTokens[1])),Double.parseDouble(truckTokens[2]),Double.parseDouble(truckTokens[3]));
        Bus bus = new Bus(Double.parseDouble(busTokens[1]),Double.parseDouble(busTokens[2]),Double.parseDouble(busTokens[3]));
        
        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            String[] tokens = scan.nextLine().split("\\s+");

            try {
                switch (tokens[0]) {
                    case "Drive":
                        switch (tokens[1]) {
                            case "Car":
                                System.out.println(car.drive(Double.parseDouble(tokens[2])));
                                break;
                            case "Truck":
                                System.out.println(truck.drive(Double.parseDouble(tokens[2])));
                                break;
                            case "Bus":
                                bus.setEmpty(true);
                                System.out.println(bus.drive(Double.parseDouble(tokens[2])));
                                break;
                        }
                        break;
                    case "Refuel":
                        switch (tokens[1]) {
                            case "Car":
                                car.refuel(Double.parseDouble(tokens[2]));
                                break;
                            case "Truck":
                                truck.refuel(Double.parseDouble(tokens[2]));
                                break;
                            case "Bus":
                                bus.refuel(Double.parseDouble(tokens[2]));
                                break;
                        }
                        break;
                    case "DriveEmpty":
                        bus.setEmpty(false);
                        System.out.println(bus.drive(Double.parseDouble(tokens[2])));
                        break;
                }
            }
            catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        }

        System.out.printf("Car: %.2f%n",car.getFuelQuantity());
        System.out.printf("Truck: %.2f%n",truck.getFuelQuantity());
        System.out.printf("Bus: %.2f",bus.getFuelQuantity());
    }
}
