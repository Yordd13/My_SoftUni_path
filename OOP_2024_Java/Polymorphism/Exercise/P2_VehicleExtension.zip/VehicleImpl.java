import java.text.DecimalFormat;

public abstract class VehicleImpl implements Vehicle{
    private double fuelQuantity;
    private double fuelConsumption;
    private double tankCapacity;

    public VehicleImpl(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        this.fuelConsumption = fuelConsumption;
        this.tankCapacity = tankCapacity;
        this.fuelQuantity =fuelQuantity;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public double getTankCapacity() {
        return tankCapacity;
    }

    public void setTankCapacity(double tankCapacity) {
        this.tankCapacity = tankCapacity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    @Override
    public String drive(double distance) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        if(getFuelQuantity() >= getFuelConsumption() * distance){
            this.fuelQuantity -= fuelConsumption * distance;
            return String.format("%s travelled %s km",this.getClass().getSimpleName(),decimalFormat.format(distance));
        }
        return this.getClass().getSimpleName() + " needs refueling";
    }

    @Override
    public void refuel(double litters) {
        if(litters <= 0){
            throw new IllegalArgumentException("Fuel must be a positive number");
        }

        double change = this.fuelQuantity + litters;

        if(change > this.tankCapacity){
            throw new IllegalArgumentException("Cannot fit fuel in tank");
        }

        else this.fuelQuantity += litters;
    }
}
