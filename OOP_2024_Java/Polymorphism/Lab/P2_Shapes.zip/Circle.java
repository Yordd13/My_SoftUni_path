public class Circle extends Shape{
    private Double radius;

    public Circle(Double radius){
        this.setRadius(radius);
        this.calculatePerimeter();
        this.calculateArea();
    }

    public final Double getRadius() {
        return radius;
    }

    protected void setRadius(Double radius) {
        this.radius = radius;
    }

    @Override
    protected void calculatePerimeter() {
        System.out.println(2 * Math.PI * this.radius);
    }

    @Override
    protected void calculateArea() {
        System.out.println(Math.PI * this.radius * this.radius);
    }
}
