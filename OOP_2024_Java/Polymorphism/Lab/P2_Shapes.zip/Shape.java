public abstract class Shape {
    private Double perimeter;
    private Double area;

    protected void setParameter(Double perimeter){
        this.perimeter = perimeter;
    }

    public Double getArea() {
        return area;
    }

    public Double getPerimeter() {
        return perimeter;
    }
    protected void setArea(Double area){
        this.area = area;
    }
    protected abstract void calculatePerimeter();
    protected abstract void calculateArea();
}
