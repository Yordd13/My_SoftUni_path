import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Class richSoilLand = RichSoilLand.class;

		Field[] fields = richSoilLand.getDeclaredFields();


		String line;
		while (!(line = scan.nextLine()).equals("HARVEST")){
            for (Field field : fields) {
                boolean checker = false;
                switch (line) {
                    case "private":
                        if (Modifier.isPrivate(field.getModifiers())) {
                            checker = true;
                        }
                        break;
                    case "protected":
                        if (Modifier.isProtected(field.getModifiers())) {
                            checker = true;
                        }
                        break;
                    case "public":
                        if (Modifier.isPublic(field.getModifiers())) {
                            checker = true;
                        }
                        break;
                    case "all":
                        checker = true;
                        break;
                }

                if (checker) {
                    System.out.printf("%s %s %s%n", Modifier.toString(field.getModifiers()), field.getType().getSimpleName(), field.getName());
                }
            }
		}
	}
}
