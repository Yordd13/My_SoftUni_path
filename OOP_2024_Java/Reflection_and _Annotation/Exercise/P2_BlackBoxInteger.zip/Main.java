import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        Scanner scan = new Scanner(System.in);

        Class<BlackBoxInt> boxInt = BlackBoxInt.class;

        Constructor<BlackBoxInt> privateConstructor = boxInt.getDeclaredConstructor();
        privateConstructor.setAccessible(true);

        BlackBoxInt blackBoxInt = privateConstructor.newInstance();

        String line;
        while (!(line = scan.nextLine()).equals("END")){
            String[] commands = line.split("_");
            String name = commands[0];
            int value = Integer.parseInt(commands[1]);

            Method method = boxInt.getDeclaredMethod(name,int.class);
            method.setAccessible(true);

            method.invoke(blackBoxInt,value);

            Field innerValue = boxInt.getDeclaredField("innerValue");
            innerValue.setAccessible(true);

            System.out.println(innerValue.get(blackBoxInt));
        }

    }
}
