package barracksWars.core.commands;

import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

public class ReportCommand extends Command{
    public ReportCommand(Repository repository, UnitFactory unitFactory, String[] data) {
        super(repository, unitFactory, data);
    }

    @Override
    public String execute() {
        return this.getRepository().getStatistics();
    }
}
